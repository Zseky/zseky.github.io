var _STRINGS = {
	"Ad":{
		"Mobile":{
			"Preroll":{
				"ReadyIn":"The game is ready in ",
				"Loading":"Your game is loading...",
				"Close":"Close",
			},
			"Header":{
				"ReadyIn":"The game is ready in ",
				"Loading":"Your game is loading...",
				"Close":"Close",
			},
			"End":{
				"ReadyIn":"Advertisement ends in ",
				"Loading":"Please wait ...",
				"Close":"Close",
			},								
		},
	},
	
	"Splash":{
		"Loading":"Loading ...",	
		"LogoLine1":"Some text here",
		"LogoLine2":"powered by MarketJS",
		"LogoLine3":"none",		
        "TapToStart":"TAP TO START",				
	},

	"Game":{
		"SelectPlayer":"Select Player",
		"Lose":"LEVEL FAILED",
		"Pause":"PAUSED",
		"Level": "LEVEL",
		"Complete":"COMPLETED!",
		"Settings": "SETTINGS",
		"Correct":"correct",
		"Wrong": "wrong",
		"Place": "place",
		"Incorrect": "incorrect",
		"RewardVideo": "REWARD",
		"RewardCallbackSuccess": "SUCCESS",
		"RewardCallbackFailed": "FAILED"

	},

	"Results":{
		"Title":"High score",
	},	
};